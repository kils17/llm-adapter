"""
BGE Gateway – FastAPI proxy for vLLM embedding & reranking endpoints.

Usage:
    EMBEDDING_URL=http://host:8001 RERANK_URL=http://host:8002 uvicorn main:app --port 8000

Or pass URLs via CLI:
    uvicorn main:app --port 8000  (then configure via /docs)
"""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional, Union

import ssl

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

class Settings(BaseSettings):
    embedding_url: str = Field(
        default="https://10.124.148.200:13001",
        description="Base URL of the vLLM embedding server",
    )
    rerank_url: str = Field(
        default="https://10.124.148.200:8001",
        description="Base URL of the vLLM reranking server",
    )
    rerank_upstream_endpoint: str = Field(
        default="/score",
        description="Upstream rerank endpoint path: '/score' or '/v1/rerank'",
    )
    request_timeout: float = Field(
        default=60.0,
        description="HTTP request timeout in seconds",
    )

    # --- mTLS: Embedding upstream ---
    embedding_client_cert: Optional[str] = Field(
        default="backend/embedding_client_cert.pem",
        description="Path to client certificate for embedding upstream",
    )
    embedding_client_key: Optional[str] = Field(
        default="backend/embedding_client_key.pem",
        description="Path to client key for embedding upstream",
    )
    embedding_server_cert: Optional[str] = Field(
        default="backend/embedding_server_cert.pem",
        description="Path to CA/server cert to verify embedding upstream",
    )

    # --- mTLS: Reranking upstream ---
    reranking_client_cert: Optional[str] = Field(
        default="backend/reranking_client_cert.pem",
        description="Path to client certificate for reranking upstream",
    )
    reranking_client_key: Optional[str] = Field(
        default="backend/reranking_client_key.pem",
        description="Path to client key for reranking upstream",
    )
    reranking_server_cert: Optional[str] = Field(
        default="backend/reranking_server_cert.pem",
        description="Path to CA/server cert to verify reranking upstream",
    )

    # --- TLS: Gateway server (optional HTTPS serving) ---
    ssl_certfile: Optional[str] = Field(
        default=None,
        description="Path to SSL cert for gateway HTTPS serving",
    )
    ssl_keyfile: Optional[str] = Field(
        default=None,
        description="Path to SSL key for gateway HTTPS serving",
    )

    model_config = {"env_prefix": "", "case_sensitive": False}


settings = Settings()

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)
logger = logging.getLogger("bge-gw")

# ---------------------------------------------------------------------------
# HTTP client lifecycle
# ---------------------------------------------------------------------------

_embedding_client: Optional[httpx.AsyncClient] = None
_rerank_client: Optional[httpx.AsyncClient] = None


def _build_ssl_context(
    client_cert: Optional[str],
    client_key: Optional[str],
    server_cert: Optional[str],
) -> Optional[ssl.SSLContext]:
    """Build an SSL context for mTLS upstream connections."""
    if not client_cert and not server_cert:
        return None

    ctx = ssl.create_default_context()

    if server_cert:
        # Trust the upstream server's CA/cert
        ctx.load_verify_locations(server_cert)
        # IP 주소로 접속 시 인증서 SAN에 IP가 없을 수 있으므로 hostname 검증 비활성화
        # (서버 인증서 자체는 여전히 검증됨)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_REQUIRED
    else:
        # If no explicit server cert, disable verification (not recommended for prod)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

    if client_cert:
        # Present client certificate for mTLS
        ctx.load_cert_chain(certfile=client_cert, keyfile=client_key)

    return ctx


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _embedding_client, _rerank_client

    timeout = httpx.Timeout(settings.request_timeout)

    # Build SSL contexts for each upstream
    embedding_ssl = _build_ssl_context(
        settings.embedding_client_cert,
        settings.embedding_client_key,
        settings.embedding_server_cert,
    )
    rerank_ssl = _build_ssl_context(
        settings.reranking_client_cert,
        settings.reranking_client_key,
        settings.reranking_server_cert,
    )

    _embedding_client = httpx.AsyncClient(
        timeout=timeout,
        verify=embedding_ssl if embedding_ssl else True,
    )
    _rerank_client = httpx.AsyncClient(
        timeout=timeout,
        verify=rerank_ssl if rerank_ssl else True,
    )

    logger.info("BGE Gateway started")
    logger.info("  EMBEDDING_URL = %s", settings.embedding_url)
    logger.info("  RERANK_URL    = %s", settings.rerank_url)
    logger.info("  Embedding mTLS = %s", "enabled" if embedding_ssl else "disabled")
    logger.info("  Reranking mTLS = %s", "enabled" if rerank_ssl else "disabled")
    yield
    await _embedding_client.aclose()
    await _rerank_client.aclose()
    logger.info("BGE Gateway stopped")


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(
    title="BGE Gateway",
    description="Proxy for vLLM embedding & reranking APIs",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------


class EmbeddingRequest(BaseModel):
    model: str = Field(..., description="Model name (e.g. BAAI/bge-large-en-v1.5)")
    input: Union[str, List[str]] = Field(..., description="Text(s) to embed")
    encoding_format: Optional[str] = Field(default="float", description="float or base64")
    dimensions: Optional[int] = None
    truncate_prompt_tokens: Optional[int] = None
    user: Optional[str] = None


class EmbeddingData(BaseModel):
    index: int
    object: str = "embedding"
    embedding: Union[List[float], str]


class EmbeddingUsage(BaseModel):
    prompt_tokens: int
    total_tokens: int
    completion_tokens: int = 0


class EmbeddingResponse(BaseModel):
    id: str
    object: str = "list"
    created: int
    model: str
    data: List[EmbeddingData]
    usage: EmbeddingUsage


class ScoreRequest(BaseModel):
    text_1: Union[str, List[str]] = Field(..., description="Query text(s)")
    text_2: Union[str, List[str]] = Field(..., description="Document text(s) to score against")
    model: Optional[str] = Field(default=None, description="Model name")
    truncate_prompt_tokens: Optional[int] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _forward(
    method: str,
    base_url: str,
    path: str,
    body: Optional[Dict[str, Any]] = None,
    client: Optional[httpx.AsyncClient] = None,
) -> Dict[str, Any]:
    """Forward a request to the upstream vLLM server."""
    url = f"{base_url.rstrip('/')}{path}"
    http_client = client or _embedding_client
    t0 = time.perf_counter()
    try:
        resp = await http_client.request(method, url, json=body)  # type: ignore[union-attr]
        elapsed = time.perf_counter() - t0
        logger.info("%s %s -> %s (%.3fs)", method, url, resp.status_code, elapsed)
        if resp.status_code >= 400:
            detail = resp.text
            try:
                detail = resp.json()
            except Exception:
                pass
            raise HTTPException(status_code=resp.status_code, detail=detail)
        return resp.json()
    except httpx.RequestError as exc:
        logger.error("Upstream request failed: %s", exc)
        raise HTTPException(status_code=502, detail=f"Upstream error: {exc}") from exc


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.get("/health")
async def health():
    """Gateway health check."""
    return {
        "status": "ok",
        "embedding_url": settings.embedding_url,
        "rerank_url": settings.rerank_url,
    }


@app.get("/health/upstream")
async def health_upstream():
    """Check connectivity to upstream vLLM servers."""
    results: Dict[str, Any] = {}

    for name, base_url, client in [
        ("embedding", settings.embedding_url, _embedding_client),
        ("rerank", settings.rerank_url, _rerank_client),
    ]:
        try:
            resp = await client.get(  # type: ignore[union-attr]
                f"{base_url.rstrip('/')}/health",
                timeout=5.0,
            )
            results[name] = {"status": "ok", "code": resp.status_code}
        except Exception as exc:
            results[name] = {"status": "error", "detail": str(exc)}

    return results


# ---- Embedding ----------------------------------------------------------


@app.post("/v1/embeddings", response_model=EmbeddingResponse)
async def create_embedding(req: EmbeddingRequest):
    """Proxy embedding request to the vLLM embedding server."""
    body = req.model_dump(exclude_none=True)
    data = await _forward("POST", settings.embedding_url, "/v1/embeddings", body, client=_embedding_client)
    return data


# ---- Reranking / Score ---------------------------------------------------


def _rerank_response_to_score(rerank_data: Dict[str, Any]) -> Any:
    """Convert /v1/rerank response to /score response format.

    /v1/rerank returns: {"results": [{"index": 0, "relevance_score": 0.82, "document": {...}}]}
                        (sorted by relevance_score descending)
    /score expects:     [{"index": 0, "score": 0.82}, ...]
                        (sorted by index, i.e. input order)
    """
    results = rerank_data.get("results", [])
    converted = [
        {"index": item["index"], "score": item["relevance_score"]}
        for item in results
    ]
    # /score는 index 순서로 반환 (입력 순서 유지)
    converted.sort(key=lambda x: x["index"])
    return converted


@app.post("/score")
async def score(req: ScoreRequest):
    """Proxy score request (text_1/text_2 format). Always returns /score format."""
    if settings.rerank_upstream_endpoint == "/score":
        # 그대로 전달, 응답도 그대로
        body = req.model_dump(exclude_none=True)
        data = await _forward(
            "POST", settings.rerank_url, "/score", body, client=_rerank_client,
        )
        return data
    else:
        # 요청: text_1/text_2 → query/documents 변환
        documents = req.text_2 if isinstance(req.text_2, list) else [req.text_2]
        body: Dict[str, Any] = {
            "query": req.text_1 if isinstance(req.text_1, str) else req.text_1[0],
            "documents": documents,
        }
        if req.model:
            body["model"] = req.model
        if req.truncate_prompt_tokens is not None:
            body["truncate_prompt_tokens"] = req.truncate_prompt_tokens

        data = await _forward(
            "POST", settings.rerank_url, "/v1/rerank", body, client=_rerank_client,
        )
        # 응답: /v1/rerank → /score 형식으로 변환
        return _rerank_response_to_score(data)


# ---- Raw passthrough (catch-all for other vLLM endpoints) ---------------


@app.api_route(
    "/v1/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE"],
    include_in_schema=False,
)
async def passthrough(request: Request, path: str):
    """
    Catch-all: forwards unmatched /v1/* requests to the embedding server
    by default. Useful for /v1/models, etc.
    """
    body = None
    if request.method in ("POST", "PUT"):
        body = await request.json()

    # Heuristic: route rerank-related paths to the rerank server
    if "rerank" in path or "score" in path:
        base = settings.rerank_url
        client = _rerank_client
    else:
        base = settings.embedding_url
        client = _embedding_client

    return await _forward(request.method, base, f"/v1/{path}", body, client=client)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import uvicorn

    kwargs: Dict[str, Any] = {
        "app": "main:app",
        "host": "0.0.0.0",
        "port": 8080,
        "reload": True,
    }

    # Enable HTTPS serving if certs are configured
    if settings.ssl_certfile and settings.ssl_keyfile:
        kwargs["ssl_certfile"] = settings.ssl_certfile
        kwargs["ssl_keyfile"] = settings.ssl_keyfile
        logger.info("Gateway HTTPS enabled with cert=%s", settings.ssl_certfile)

    uvicorn.run(**kwargs)
