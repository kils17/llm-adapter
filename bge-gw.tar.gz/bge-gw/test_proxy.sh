#!/bin/bash
# =============================================================================
# BGE Gateway Proxy - curl test script (with mTLS support)
# 서버 기동: python main.py (또는 uvicorn main:app --port 8080)
# =============================================================================

# --- 서버 URL 설정 ---
RERANK_URL="${RERANK_URL:-http://localhost:8080}"
EMBEDDING_URL="${EMBEDDING_URL:-http://localhost:8080}"

# --- 인증서 경로 설정 (mTLS 사용 시) ---
CERT_DIR="${CERT_DIR:-./backend}"

EMBEDDING_CLIENT_CERT="${EMBEDDING_CLIENT_CERT:-${CERT_DIR}/embedding_client_cert.pem}"
EMBEDDING_CLIENT_KEY="${EMBEDDING_CLIENT_KEY:-${CERT_DIR}/embedding_client_key.pem}"
EMBEDDING_CA_CERT="${EMBEDDING_CA_CERT:-${CERT_DIR}/embedding_server_cert.pem}"

RERANKING_CLIENT_CERT="${RERANKING_CLIENT_CERT:-${CERT_DIR}/reranking_client_cert.pem}"
RERANKING_CLIENT_KEY="${RERANKING_CLIENT_KEY:-${CERT_DIR}/reranking_client_key.pem}"
RERANKING_CA_CERT="${RERANKING_CA_CERT:-${CERT_DIR}/reranking_server_cert.pem}"

# --- TLS 모드 선택 ---
USE_TLS="${USE_TLS:-0}"

# --- curl TLS 옵션 빌드 ---
EMBEDDING_TLS_OPTS=""
RERANKING_TLS_OPTS=""

if [ "$USE_TLS" = "1" ]; then
    if [ -f "$EMBEDDING_CLIENT_CERT" ] && [ -f "$EMBEDDING_CLIENT_KEY" ]; then
        EMBEDDING_TLS_OPTS="--cert ${EMBEDDING_CLIENT_CERT} --key ${EMBEDDING_CLIENT_KEY}"
    fi
    if [ -f "$EMBEDDING_CA_CERT" ]; then
        EMBEDDING_TLS_OPTS="${EMBEDDING_TLS_OPTS} --cacert ${EMBEDDING_CA_CERT}"
    fi
    if [ -f "$RERANKING_CLIENT_CERT" ] && [ -f "$RERANKING_CLIENT_KEY" ]; then
        RERANKING_TLS_OPTS="--cert ${RERANKING_CLIENT_CERT} --key ${RERANKING_CLIENT_KEY}"
    fi
    if [ -f "$RERANKING_CA_CERT" ]; then
        RERANKING_TLS_OPTS="${RERANKING_TLS_OPTS} --cacert ${RERANKING_CA_CERT}"
    fi
fi

# --- 헬퍼 함수: curl 실행 후 상태코드와 JSON 응답을 분리 출력 ---
do_curl() {
    local tmpfile
    tmpfile=$(mktemp /tmp/curl_resp.XXXXXX)
    local http_code
    http_code=$(curl -s -o "$tmpfile" -w "%{http_code}" "$@")
    echo "HTTP Status: ${http_code}"
    if python3 -m json.tool "$tmpfile" 2>/dev/null; then
        :
    else
        cat "$tmpfile"
        echo ""
    fi
    rm -f "$tmpfile"
}

echo "=========================================="
echo " BGE Gateway Proxy Test Script"
echo " Rerank URL : ${RERANK_URL}"
echo " Embedding URL: ${EMBEDDING_URL}"
echo " TLS mode   : $([ "$USE_TLS" = "1" ] && echo "ENABLED" || echo "DISABLED")"
echo "=========================================="
echo ""

# -----------------------------------------------------------------------------
# 1. Health Check
# -----------------------------------------------------------------------------
echo "--- [1] Health Check for RERANK ---"
do_curl ${RERANKING_TLS_OPTS} "${RERANK_URL}/health"
echo ""

echo "--- [2] Health Check for EMBEDDING ---"
do_curl ${EMBEDDING_TLS_OPTS} "${EMBEDDING_URL}/health"
echo ""

# -----------------------------------------------------------------------------
# 2. Embedding - 단일 텍스트
# -----------------------------------------------------------------------------
echo "--- [3] Embedding (single text) ---"
do_curl ${EMBEDDING_TLS_OPTS} \
  -X POST "${EMBEDDING_URL}/v1/embeddings" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-m3",
    "input": "Hello, world!",
    "encoding_format": "float"
  }'
echo ""

# -----------------------------------------------------------------------------
# 3. Embedding - 다중 텍스트 (batch)
# -----------------------------------------------------------------------------
echo "--- [4] Embedding (batch texts) ---"
do_curl ${EMBEDDING_TLS_OPTS} \
  -X POST "${EMBEDDING_URL}/v1/embeddings" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-m3",
    "input": [
      "Machine learning is a subset of artificial intelligence.",
      "Natural language processing deals with text data.",
      "Computer vision focuses on image understanding."
    ],
    "encoding_format": "float"
  }'
echo ""

# -----------------------------------------------------------------------------
# 4. Embedding - base64 encoding format
# -----------------------------------------------------------------------------
echo "--- [5] Embedding (base64 format) ---"
do_curl ${EMBEDDING_TLS_OPTS} \
  -X POST "${EMBEDDING_URL}/v1/embeddings" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-m3",
    "input": "Test base64 encoding",
    "encoding_format": "base64"
  }'
echo ""

# -----------------------------------------------------------------------------
# 5. Score - /score 엔드포인트 (text_1/text_2 형식)
# -----------------------------------------------------------------------------
echo "--- [6] Score /score (text_1/text_2) ---"
do_curl ${RERANKING_TLS_OPTS} \
  -X POST "${RERANK_URL}/score" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-reranker-v2-m3",
    "text_1": "What is machine learning?",
    "text_2": [
      "Machine learning is a branch of artificial intelligence that enables systems to learn from data.",
      "Python is a popular programming language used in web development.",
      "Deep learning is a subset of machine learning that uses neural networks with many layers.",
      "The weather today is sunny with a high of 25 degrees.",
      "Supervised learning requires labeled training data to make predictions."
    ]
  }'
echo ""

# -----------------------------------------------------------------------------
# 6. Score - /score 한국어
# -----------------------------------------------------------------------------
echo "--- [7] Score /score (Korean) ---"
do_curl ${RERANKING_TLS_OPTS} \
  -X POST "${RERANK_URL}/score" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-reranker-v2-m3",
    "text_1": "인공지능의 발전 방향은?",
    "text_2": [
      "인공지능은 머신러닝과 딥러닝을 통해 빠르게 발전하고 있습니다.",
      "오늘 서울의 날씨는 맑고 기온은 20도입니다.",
      "대규모 언어 모델은 AI 발전의 핵심 동력입니다.",
      "한국의 수도는 서울이며 인구는 약 1000만명입니다."
    ]
  }'
echo ""

# -----------------------------------------------------------------------------
# 8. Embedding - 한국어 테스트
# -----------------------------------------------------------------------------
echo "--- [8] Embedding (Korean) ---"
do_curl ${EMBEDDING_TLS_OPTS} \
  -X POST "${EMBEDDING_URL}/v1/embeddings" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bge-m3",
    "input": [
      "인공지능은 컴퓨터 과학의 한 분야입니다.",
      "자연어 처리는 텍스트 데이터를 다룹니다."
    ],
    "encoding_format": "float"
  }'
echo ""

echo "=========================================="
echo " Done!"
echo "=========================================="
